package de.deltatree.social.web.filter.impl.props;

public class SASFPropertiesException extends Exception {
	private static final long serialVersionUID = 1L;

	public SASFPropertiesException(String message) {
		super(message);
	}
}
